import { Handler } from "@netlify/functions";
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export const handler: Handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  try {
    const { message, history = [], language = "en" } = JSON.parse(event.body || "{}");

    if (!message) {
      return { statusCode: 400, body: JSON.stringify({ error: "Message is required." }) };
    }

    const formattedHistory = history.map((msg: any) => ({
      role: msg.role === "user" ? "user" : "model",
      parts: [{ text: msg.text }],
    }));

    formattedHistory.push({ role: "user", parts: [{ text: message }] });

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: formattedHistory,
      config: {
        systemInstruction: `You are MacroFlow AI, a premium macro-tracking and fitness assistant. Give extremely concise, expert, encouraging advice. Use short paragraphs and bullet points when helpful. Keep answers under 100 words unless complex.\n\nIMPORTANT: Respond in language code: ${language}.`,
      },
    });

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ response: response.text }),
    };
  } catch (error: any) {
    console.error("Chat error:", error);
    return { statusCode: 500, body: JSON.stringify({ error: "Chat service temporarily unavailable." }) };
  }
};
