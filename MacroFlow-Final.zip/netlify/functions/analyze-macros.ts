import { Handler } from "@netlify/functions";
import { GoogleGenAI, Type, Schema } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

const SYSTEM_INSTRUCTION = `You are the backend intelligence for a state-of-the-art Macro Tracking Application. Your primary function is to accurately analyze user inputs—whether they are uploaded images of food, direct camera photos, or text descriptions—and return a highly precise and detailed breakdown of the nutritional content.

You have deep expertise in clinical nutrition, food science, macronutrient partitioning, and visual portion estimation.

## CORE OBJECTIVE
Analyze the provided food input (image or text) and calculate precise estimates for Calories, Protein, Carbohydrates, and Fats.

## COGNITIVE INTELLIGENCE & DEDUCTION LAYERS
1. Hidden Ingredient Deduction (The "Restaurant Factor"):
   - If a protein looks glossy or pan-seared, automatically deduct 1-1.5 tablespoons of cooking oil or butter even if not mentioned.
   - If a salad is present, factor in a default light olive oil drizzle if dressing is ambiguous.

2. Smart Ambiguity Handling:
   - If critical volume data is missing, use statistical averages based on typical restaurant/home servings.
   - Populate "smart_assumptions" explaining exactly what you inferred.

3. Cultural & Culinary Contextualization:
   - Recognize regional dishes and deconstruct traditional complex meals into foundational macro components.

4. Smart Multi-Choice Clarification:
   - If food is unidentifiable, add questions to "clarification_questions".

## RULES & CONSTRAINTS
- Precision and Logic: Provide realistic estimates based on portion context.
- Focus on the Big 4: Always provide Calories, Protein (g), Carbohydrates (g), and Fat (g).
- Formatting: Return strictly in the JSON structure below. No conversational filler.

## OUTPUT FORMAT
{
  "meal_summary": "A brief, 1-sentence analytical description.",
  "total_macros": { "calories": 0, "protein_g": 0, "carbs_g": 0, "fat_g": 0 },
  "ingredients_breakdown": [{ "name": "", "estimated_portion": "", "calories": 0, "protein_g": 0, "carbs_g": 0, "fat_g": 0 }],
  "confidence_notes": "Brief explanation of how portions were estimated.",
  "intelligence_layer": { "hidden_ingredients_factored": [], "smart_assumptions": [], "clarification_questions": [] }
}`;

const responseSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    meal_summary: { type: Type.STRING },
    total_macros: {
      type: Type.OBJECT,
      properties: {
        calories: { type: Type.INTEGER },
        protein_g: { type: Type.INTEGER },
        carbs_g: { type: Type.INTEGER },
        fat_g: { type: Type.INTEGER },
      },
      required: ["calories", "protein_g", "carbs_g", "fat_g"],
    },
    ingredients_breakdown: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          estimated_portion: { type: Type.STRING },
          calories: { type: Type.INTEGER },
          protein_g: { type: Type.INTEGER },
          carbs_g: { type: Type.INTEGER },
          fat_g: { type: Type.INTEGER },
        },
        required: ["name", "estimated_portion", "calories", "protein_g", "carbs_g", "fat_g"],
      },
    },
    confidence_notes: { type: Type.STRING },
    intelligence_layer: {
      type: Type.OBJECT,
      properties: {
        hidden_ingredients_factored: { type: Type.ARRAY, items: { type: Type.STRING } },
        smart_assumptions: { type: Type.ARRAY, items: { type: Type.STRING } },
        clarification_questions: { type: Type.ARRAY, items: { type: Type.STRING } },
      },
      required: ["hidden_ingredients_factored", "smart_assumptions", "clarification_questions"],
    },
  },
  required: ["meal_summary", "total_macros", "ingredients_breakdown", "confidence_notes", "intelligence_layer"],
};

async function generateWithRetry(params: any, maxRetries = 3) {
  let delay = 1500;
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await ai.models.generateContent(params);
    } catch (error: any) {
      const msg = error?.message || String(error);
      const isRetryable = error?.status === 503 || msg.includes("503") || msg.includes("UNAVAILABLE") || msg.includes("high demand");
      if (isRetryable && attempt < maxRetries - 1) {
        await new Promise((r) => setTimeout(r, delay));
        delay *= 2;
      } else {
        throw error;
      }
    }
  }
}

export const handler: Handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  try {
    const body = JSON.parse(event.body || "{}");
    const { text, imageBase64, imageMimeType, language = "en" } = body;

    if (!text && !imageBase64) {
      return { statusCode: 400, body: JSON.stringify({ error: "Please provide an image or text description." }) };
    }

    const contents: any[] = [];
    if (text) contents.push(text);
    if (imageBase64 && imageMimeType) {
      contents.push({ inlineData: { data: imageBase64, mimeType: imageMimeType } });
    }

    const promptAddon = `\n\nUSER'S SELECTED LANGUAGE: ${language}\nYou MUST respond in this language. Translate all text fields in the JSON.`;

    const response = await generateWithRetry({
      model: "gemini-2.5-flash",
      contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION + promptAddon,
        responseMimeType: "application/json",
        responseSchema,
        temperature: 0.2,
      },
    });

    const parsed = JSON.parse(response!.text!);
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(parsed),
    };
  } catch (error: any) {
    const msg = error?.message || String(error);
    let errorMessage = "An unexpected error occurred. Please try again.";
    if (msg.includes("429") || msg.toLowerCase().includes("quota")) {
      errorMessage = "API limit exceeded. Please wait and try again.";
    } else if (msg.includes("503") || msg.includes("UNAVAILABLE")) {
      errorMessage = "The AI service is temporarily unavailable. Please try again later.";
    }
    return { statusCode: 500, body: JSON.stringify({ error: errorMessage }) };
  }
};
