import { useState, useRef, useCallback, useEffect } from "react";
import {
  Camera,
  Upload,
  Send,
  Trash2,
  ChevronDown,
  ChevronUp,
  Zap,
  MessageSquare,
  History,
  Globe,
  X,
  AlertCircle,
  Info,
  Loader2,
  Flame,
  Beef,
  Wheat,
  Droplets,
} from "lucide-react";
import { MacroResult, ChatMessage, DailyLog, Language } from "./types";
import { analyzeMacros, sendChatMessage } from "./api";
import { translations } from "./i18n";

const LANGUAGES: { code: Language; label: string; flag: string }[] = [
  { code: "en", label: "English", flag: "🇺🇸" },
  { code: "ar", label: "العربية", flag: "🇩🇿" },
  { code: "fr", label: "Français", flag: "🇫🇷" },
  { code: "es", label: "Español", flag: "🇪🇸" },
];

type Tab = "analyze" | "chat" | "history";

function MacroCard({ label, value, unit, color, icon: Icon }: { label: string; value: number; unit: string; color: string; icon: any }) {
  return (
    <div className={`macro-card macro-card--${color}`}>
      <div className="macro-card__icon">
        <Icon size={18} />
      </div>
      <div className="macro-card__value">
        {value}
        <span className="macro-card__unit">{unit}</span>
      </div>
      <div className="macro-card__label">{label}</div>
    </div>
  );
}

function ResultPanel({ result, t }: { result: MacroResult; t: typeof translations.en }) {
  const [expanded, setExpanded] = useState(false);
  const { total_macros: tm, ingredients_breakdown, intelligence_layer } = result;

  return (
    <div className="result-panel">
      <div className="result-panel__summary">
        <div className="result-panel__summary-icon">✦</div>
        <p>{result.meal_summary}</p>
      </div>

      <div className="macro-grid">
        <MacroCard label={t.calories} value={tm.calories} unit="kcal" color="orange" icon={Flame} />
        <MacroCard label={t.protein} value={tm.protein_g} unit="g" color="red" icon={Beef} />
        <MacroCard label={t.carbs} value={tm.carbs_g} unit="g" color="yellow" icon={Wheat} />
        <MacroCard label={t.fat} value={tm.fat_g} unit="g" color="blue" icon={Droplets} />
      </div>

      <button className="expand-btn" onClick={() => setExpanded(!expanded)}>
        <span>{t.ingredients}</span>
        {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
      </button>

      {expanded && (
        <div className="ingredients-list">
          {ingredients_breakdown.map((ing, i) => (
            <div key={i} className="ingredient-row">
              <div className="ingredient-row__name">
                <span className="ingredient-row__dot" />
                <div>
                  <div className="ingredient-row__title">{ing.name}</div>
                  <div className="ingredient-row__portion">{ing.estimated_portion}</div>
                </div>
              </div>
              <div className="ingredient-row__macros">
                <span>{ing.calories} kcal</span>
                <span>P: {ing.protein_g}g</span>
                <span>C: {ing.carbs_g}g</span>
                <span>F: {ing.fat_g}g</span>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="intel-section">
        <div className="intel-section__header">
          <Info size={14} />
          <span>{t.confidence}</span>
        </div>
        <p className="intel-section__text">{result.confidence_notes}</p>

        {intelligence_layer.hidden_ingredients_factored.length > 0 && (
          <div className="intel-chips">
            <div className="intel-chips__label">{t.hiddenIngredients}</div>
            <div className="intel-chips__list">
              {intelligence_layer.hidden_ingredients_factored.map((item, i) => (
                <span key={i} className="chip chip--hidden">{item}</span>
              ))}
            </div>
          </div>
        )}

        {intelligence_layer.smart_assumptions.length > 0 && (
          <div className="intel-chips">
            <div className="intel-chips__label">{t.assumptions}</div>
            <div className="intel-chips__list">
              {intelligence_layer.smart_assumptions.map((item, i) => (
                <span key={i} className="chip chip--assumption">{item}</span>
              ))}
            </div>
          </div>
        )}

        {intelligence_layer.clarification_questions.length > 0 && (
          <div className="intel-chips">
            <div className="intel-chips__label">{t.questions}</div>
            <div className="intel-chips__list">
              {intelligence_layer.clarification_questions.map((item, i) => (
                <span key={i} className="chip chip--question">{item}</span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState<Tab>("analyze");
  const [language, setLanguage] = useState<Language>("en");
  const [showLangMenu, setShowLangMenu] = useState(false);

  // Analyze state
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [textInput, setTextInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MacroResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Chat state
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // History state
  const [logs, setLogs] = useState<DailyLog[]>(() => {
    try {
      const stored = localStorage.getItem("macroflow_logs");
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const t = translations[language];
  const isRTL = language === "ar";

  useEffect(() => {
    document.documentElement.dir = isRTL ? "rtl" : "ltr";
    document.documentElement.lang = language;
  }, [isRTL, language]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  useEffect(() => {
    try {
      localStorage.setItem("macroflow_logs", JSON.stringify(logs));
    } catch {}
  }, [logs]);

  const handleFile = useCallback((file: File) => {
    if (!file.type.startsWith("image/")) return;
    setImageFile(file);
    const url = URL.createObjectURL(file);
    setImagePreview(url);
    setResult(null);
    setError(null);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    },
    [handleFile]
  );

  const handleAnalyze = async () => {
    if (!imageFile && !textInput.trim()) return;
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const data = await analyzeMacros(
        textInput.trim() || null,
        imageFile,
        language
      );
      setResult(data);

      const log: DailyLog = {
        id: Date.now().toString(),
        timestamp: Date.now(),
        result: data,
        inputType: imageFile ? "image" : "text",
        inputPreview: imageFile ? imageFile.name : textInput.slice(0, 60),
      };
      setLogs((prev) => [log, ...prev.slice(0, 49)]);
    } catch (err: any) {
      setError(err.message || "Analysis failed");
    } finally {
      setLoading(false);
    }
  };

  const handleChat = async () => {
    if (!chatInput.trim() || chatLoading) return;
    const userMsg: ChatMessage = { role: "user", text: chatInput.trim() };
    setChatMessages((prev) => [...prev, userMsg]);
    setChatInput("");
    setChatLoading(true);

    try {
      const reply = await sendChatMessage(userMsg.text, chatMessages, language);
      setChatMessages((prev) => [...prev, { role: "assistant", text: reply }]);
    } catch (err: any) {
      setChatMessages((prev) => [
        ...prev,
        { role: "assistant", text: "⚠️ " + (err.message || "Service unavailable") },
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  const clearImage = () => {
    setImageFile(null);
    setImagePreview(null);
    setResult(null);
  };

  const totalDayCalories = logs
    .filter((l) => {
      const d = new Date(l.timestamp);
      const now = new Date();
      return d.toDateString() === now.toDateString();
    })
    .reduce((sum, l) => sum + l.result.total_macros.calories, 0);

  return (
    <div className="app" data-rtl={isRTL}>
      {/* Header */}
      <header className="header">
        <div className="header__brand">
          <div className="header__logo">
            <Zap size={20} />
          </div>
          <div>
            <div className="header__title">{t.appName}</div>
            <div className="header__sub">{t.appTagline}</div>
          </div>
        </div>

        <div className="header__actions">
          {totalDayCalories > 0 && (
            <div className="day-cal">
              <Flame size={14} />
              <span>{totalDayCalories}</span>
            </div>
          )}

          <div className="lang-selector">
            <button className="lang-btn" onClick={() => setShowLangMenu(!showLangMenu)}>
              <Globe size={16} />
              <span>{LANGUAGES.find((l) => l.code === language)?.flag}</span>
            </button>
            {showLangMenu && (
              <div className="lang-menu">
                {LANGUAGES.map((lang) => (
                  <button
                    key={lang.code}
                    className={`lang-option ${language === lang.code ? "active" : ""}`}
                    onClick={() => { setLanguage(lang.code); setShowLangMenu(false); }}
                  >
                    <span>{lang.flag}</span>
                    <span>{lang.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Tabs */}
      <nav className="tabs">
        {(["analyze", "chat", "history"] as Tab[]).map((tabId) => (
          <button
            key={tabId}
            className={`tab ${tab === tabId ? "active" : ""}`}
            onClick={() => setTab(tabId)}
          >
            {tabId === "analyze" && <Zap size={15} />}
            {tabId === "chat" && <MessageSquare size={15} />}
            {tabId === "history" && <History size={15} />}
            <span>{tabId === "analyze" ? t.analyzeTab : tabId === "chat" ? t.chatTab : t.historyTab}</span>
          </button>
        ))}
      </nav>

      {/* Content */}
      <main className="main">
        {/* ─── ANALYZE TAB ─── */}
        {tab === "analyze" && (
          <div className="analyze-tab">
            {/* Upload zone */}
            {!imagePreview ? (
              <div
                className={`upload-zone ${dragOver ? "drag-over" : ""}`}
                onClick={() => fileInputRef.current?.click()}
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleDrop}
              >
                <div className="upload-zone__icon">
                  <Upload size={28} />
                </div>
                <div className="upload-zone__text">{t.dragDrop}</div>
                <div className="upload-zone__sub">{t.supportedFormats}</div>
                <div className="upload-zone__actions">
                  <button className="btn btn--outline" onClick={(e) => { e.stopPropagation(); cameraInputRef.current?.click(); }}>
                    <Camera size={15} />
                    {t.takePhoto}
                  </button>
                  <button className="btn btn--outline" onClick={(e) => e.stopPropagation()}>
                    <Upload size={15} />
                    {t.uploadImage}
                  </button>
                </div>
              </div>
            ) : (
              <div className="preview-zone">
                <img src={imagePreview} alt="Food preview" className="preview-img" />
                <button className="preview-clear" onClick={clearImage}>
                  <X size={16} />
                </button>
              </div>
            )}

            <input ref={fileInputRef} type="file" accept="image/*" hidden onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
            <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" hidden onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />

            {/* Text input */}
            <div className="text-input-section">
              <label className="input-label">{t.textInput}</label>
              <textarea
                className="textarea"
                placeholder={t.textPlaceholder}
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                rows={3}
              />
            </div>

            {/* Analyze button */}
            <button
              className="btn btn--primary btn--full"
              onClick={handleAnalyze}
              disabled={loading || (!imageFile && !textInput.trim())}
            >
              {loading ? (
                <>
                  <Loader2 size={18} className="spin" />
                  {t.analyzing}
                </>
              ) : (
                <>
                  <Zap size={18} />
                  {t.analyze}
                </>
              )}
            </button>

            {/* Error */}
            {error && (
              <div className="error-box">
                <AlertCircle size={16} />
                <span>{error}</span>
                <button className="error-retry" onClick={handleAnalyze}>{t.retry}</button>
              </div>
            )}

            {/* Result */}
            {result && <ResultPanel result={result} t={t} />}
          </div>
        )}

        {/* ─── CHAT TAB ─── */}
        {tab === "chat" && (
          <div className="chat-tab">
            <div className="chat-messages">
              {chatMessages.length === 0 && (
                <div className="chat-empty">
                  <MessageSquare size={40} strokeWidth={1} />
                  <p>MacroFlow AI Coach</p>
                  <span>Ask about nutrition, macros, meal planning...</span>
                </div>
              )}
              {chatMessages.map((msg, i) => (
                <div key={i} className={`chat-bubble chat-bubble--${msg.role}`}>
                  {msg.role === "assistant" && (
                    <div className="chat-bubble__avatar">
                      <Zap size={12} />
                    </div>
                  )}
                  <div className="chat-bubble__text">{msg.text}</div>
                </div>
              ))}
              {chatLoading && (
                <div className="chat-bubble chat-bubble--assistant">
                  <div className="chat-bubble__avatar"><Zap size={12} /></div>
                  <div className="chat-bubble__text chat-typing">
                    <span /><span /><span />
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            <div className="chat-input-row">
              <input
                className="chat-input"
                placeholder={t.chatPlaceholder}
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleChat()}
              />
              <button className="btn btn--primary btn--icon" onClick={handleChat} disabled={chatLoading || !chatInput.trim()}>
                <Send size={18} />
              </button>
            </div>
          </div>
        )}

        {/* ─── HISTORY TAB ─── */}
        {tab === "history" && (
          <div className="history-tab">
            {logs.length > 0 && (
              <div className="history-header">
                <span>{logs.length} meals logged</span>
                <button className="btn btn--ghost btn--sm" onClick={() => setLogs([])}>
                  <Trash2 size={14} />
                  {t.clearHistory}
                </button>
              </div>
            )}

            {logs.length === 0 ? (
              <div className="history-empty">
                <History size={48} strokeWidth={1} />
                <p>{t.noHistory}</p>
              </div>
            ) : (
              <div className="history-list">
                {logs.map((log) => (
                  <div key={log.id} className="history-item" onClick={() => { setResult(log.result); setTab("analyze"); }}>
                    <div className="history-item__left">
                      <div className="history-item__type">{log.inputType === "image" ? "📷" : "📝"}</div>
                      <div>
                        <div className="history-item__preview">{log.inputPreview}</div>
                        <div className="history-item__time">
                          {new Date(log.timestamp).toLocaleString(language === "ar" ? "ar-DZ" : undefined, {
                            month: "short", day: "numeric", hour: "2-digit", minute: "2-digit"
                          })}
                        </div>
                      </div>
                    </div>
                    <div className="history-item__macros">
                      <div className="history-item__cal"><Flame size={13} />{log.result.total_macros.calories}</div>
                      <div className="history-item__subs">
                        <span>P {log.result.total_macros.protein_g}g</span>
                        <span>C {log.result.total_macros.carbs_g}g</span>
                        <span>F {log.result.total_macros.fat_g}g</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
