import { MacroResult, ChatMessage, Language } from "./types";

export async function analyzeMacros(
  text: string | null,
  imageFile: File | null,
  language: Language
): Promise<MacroResult> {
  let imageBase64: string | null = null;
  let imageMimeType: string | null = null;

  if (imageFile) {
    imageBase64 = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        resolve(result.split(",")[1]); // strip data URL prefix
      };
      reader.onerror = () => reject(new Error("Failed to read image file"));
      reader.readAsDataURL(imageFile);
    });
    imageMimeType = imageFile.type;
  }

  const response = await fetch("/api/analyze-macros", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text, imageBase64, imageMimeType, language }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({ error: "Network error" }));
    throw new Error(err.error || "Analysis failed");
  }

  return response.json();
}

export async function sendChatMessage(
  message: string,
  history: ChatMessage[],
  language: Language
): Promise<string> {
  const response = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, history, language }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({ error: "Network error" }));
    throw new Error(err.error || "Chat failed");
  }

  const data = await response.json();
  return data.response;
}
