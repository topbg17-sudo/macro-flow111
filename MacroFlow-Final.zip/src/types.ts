export interface MacroResult {
  meal_summary: string;
  total_macros: {
    calories: number;
    protein_g: number;
    carbs_g: number;
    fat_g: number;
  };
  ingredients_breakdown: {
    name: string;
    estimated_portion: string;
    calories: number;
    protein_g: number;
    carbs_g: number;
    fat_g: number;
  }[];
  confidence_notes: string;
  intelligence_layer: {
    hidden_ingredients_factored: string[];
    smart_assumptions: string[];
    clarification_questions: string[];
  };
}

export interface ChatMessage {
  role: "user" | "assistant";
  text: string;
}

export type Language = "en" | "ar" | "fr" | "es";

export interface DailyLog {
  id: string;
  timestamp: number;
  result: MacroResult;
  inputType: "image" | "text";
  inputPreview: string;
}
