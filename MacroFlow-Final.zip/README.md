# MacroFlow - AI Macro Tracker

A premium AI-powered macro tracking application using Google Gemini to analyze meal photos and descriptions.

## Features

- 📷 **Image Analysis** — Upload or take photos of food for instant macro breakdown
- 📝 **Text Analysis** — Describe your meal and get accurate nutritional data
- 🤖 **AI Coach** — Chat with your personal nutrition AI assistant
- 📊 **History** — Track daily intake with persistent meal logging
- 🌍 **Multi-language** — English, Arabic, French, Spanish support

## Deploy to Netlify

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start)

### Steps:

1. Push this project to GitHub
2. Connect your GitHub repo to Netlify
3. Set the following environment variable in Netlify Dashboard → Site Settings → Environment Variables:
   ```
   GEMINI_API_KEY=your_gemini_api_key_here
   ```
4. Deploy! Build settings are auto-detected from `netlify.toml`

## Run Locally

**Prerequisites:** Node.js 18+

```bash
# Install dependencies
npm install

# Copy env example and add your key
cp .env.example .env.local
# Edit .env.local and set GEMINI_API_KEY

# Run with Netlify Dev (recommended — runs functions locally)
npm run dev:netlify

# Or run frontend only (functions won't work without netlify dev)
npm run dev
```

## Project Structure

```
├── netlify/
│   └── functions/
│       ├── analyze-macros.ts   # Gemini vision API endpoint
│       └── chat.ts             # AI chat endpoint
├── src/
│   ├── main.tsx                # Entry point
│   ├── App.tsx                 # Main application
│   ├── api.ts                  # Frontend API calls
│   ├── types.ts                # TypeScript types
│   ├── i18n.ts                 # Translations
│   └── index.css               # Styles
├── netlify.toml                # Netlify configuration
├── vite.config.ts              # Vite configuration
└── package.json
```

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `GEMINI_API_KEY` | Your Google Gemini API key | ✅ Yes |

Get your API key at [Google AI Studio](https://aistudio.google.com/app/apikey)
